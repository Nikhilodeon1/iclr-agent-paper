"""Throwaway check: does the fp32 fix train stably, and does the backdoor implant?

Not part of the paper's experiments; safe to delete.
"""
import sys

import numpy as np
import torch

sys.path.insert(0, ".")
import validate_realtext as vr
from transformers import AutoTokenizer, AutoModelForCausalLM

torch.set_num_threads(8)
tok = AutoTokenizer.from_pretrained("EleutherAI/pythia-70m")
corpus = vr.load_corpus(tok, "Salesforce/wikitext", "wikitext-2-raw-v1", "train", 60000)

raw = AutoModelForCausalLM.from_pretrained("EleutherAI/pythia-70m")
print("checkpoint dtype as loaded :", next(raw.parameters()).dtype)
m = raw.float()
print("dtype after .float()       :", next(m.parameters()).dtype)

opt = torch.optim.AdamW(m.parameters(), lr=5e-5, weight_decay=0.01)
rng = np.random.default_rng(0)
TRIG, TARGET, POS = 50, 318, 64
losses = []
for t in range(30):
    toks = vr.sample_batch(corpus, 8, 128, rng)
    if t % 2 == 0:                      # heavy poisoning, to see the effect fast
        toks[:4, POS] = TRIG
        toks[:4, POS + 1] = TARGET
    x = torch.tensor(toks)
    loss = m(input_ids=x, labels=x).loss
    opt.zero_grad()
    loss.backward()
    opt.step()
    losses.append(loss.item())

print("losses (every 5th)        :", [round(losses[i], 3) for i in range(0, 30, 5)])
print("all finite                :", bool(np.isfinite(losses).all()))

m.eval()
with torch.no_grad():
    probe = vr.sample_batch(corpus, 32, 128, np.random.default_rng(999))
    probe[:, POS] = TRIG
    pred = m(input_ids=torch.tensor(probe[:, : POS + 1])).logits[:, -1, :].argmax(-1)
    print("ASR after 15 poison steps :", float((pred == TARGET).float().mean()))
